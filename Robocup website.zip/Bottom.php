    <div id="Elements-Placement-2">
<div class="container" id="PicturesHeading">
	<div>Photos</div>
	</div>
	
	<div class="container" id="Pictures">
	 <a href="img/RoboCup-1.jpg"><img src="img/RoboCup-1.jpg"     alt="IMG"     title="IMG1" width="30%"/></a>
	 	 <a href="img/RoboCup-2.jpg"><img src="img/RoboCup-2.jpg"     alt="IMG"     title="IMG2" width="30%"/></a>
		 	 <a href="img/RoboCup-3.jpg"><img src="img/RoboCup-3.jpg"     alt="IMG"     title="IMG3" width="30%"/></a>
			 	 <a href="img/RoboCup-4.jpg"><img src="img/RoboCup-4.jpg"     alt="IMG"     title="IMG4" width="30%"/></a>
				 	<a href="img/RoboCup-5.jpg"><img src="img/RoboCup-5.jpg"     alt="IMG"     title="IMG5" width="30%"/></a>
						 <a href="img/RoboCup-6.jpg"><img src="img/RoboCup-6.jpg"     alt="IMG"     title="IMG6" width="30%"/></a>
	</div>
	
	
        <br><br>
        <a class="twitter-timeline"  href="https://twitter.com/ProShotsMessage" data-widget-id="601667949028585472">Tweets by @ProShotsMessage</a>
        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

    </div>

<br><br><br>

<!-- Footer -->
<footer style = "background-color:black; height: 100px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                <p class="copyright text-muted">Contact us on Robocup2015Netherland@gmail.com</p>
            </div>
        </div>
    </div>
</footer>

