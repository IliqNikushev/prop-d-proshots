<?php
$Pay =$_POST["pay"];
echo json_encode($Pay);

?>