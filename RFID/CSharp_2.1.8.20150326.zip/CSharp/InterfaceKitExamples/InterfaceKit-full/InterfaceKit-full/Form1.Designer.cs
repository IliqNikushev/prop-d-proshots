namespace InterfaceKit_full
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.sensorInNumTxt = new System.Windows.Forms.TextBox();
            this.digiOutNumTxt = new System.Windows.Forms.TextBox();
            this.digiInNumTxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.versionTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.serialTxt = new System.Windows.Forms.TextBox();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.attachedTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.analogInputsGroupBox = new System.Windows.Forms.GroupBox();
            this.sensorsButton = new System.Windows.Forms.Button();
            this.inputTrk = new System.Windows.Forms.TrackBar();
            this.sensitivityTxt = new System.Windows.Forms.TextBox();
            this.analogInputLabel7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ratioChk = new System.Windows.Forms.CheckBox();
            this.analogInputLabel6 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.analogInputLabel5 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.analogInputLabel4 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.analogInputLabel3 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.analogInputLabel2 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.analogInputLabel1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.analogInputLabel0 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.digitalOutputsGroupBox = new System.Windows.Forms.GroupBox();
            this.checkBoxReport0 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport1 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport2 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport3 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport4 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport5 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport6 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport7 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport8 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport9 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport10 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport11 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport12 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport13 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport14 = new System.Windows.Forms.CheckBox();
            this.checkBoxReport15 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel15 = new System.Windows.Forms.Label();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel14 = new System.Windows.Forms.Label();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel13 = new System.Windows.Forms.Label();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel12 = new System.Windows.Forms.Label();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel11 = new System.Windows.Forms.Label();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel10 = new System.Windows.Forms.Label();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel9 = new System.Windows.Forms.Label();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel8 = new System.Windows.Forms.Label();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel7 = new System.Windows.Forms.Label();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel6 = new System.Windows.Forms.Label();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel5 = new System.Windows.Forms.Label();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel4 = new System.Windows.Forms.Label();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel3 = new System.Windows.Forms.Label();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel2 = new System.Windows.Forms.Label();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel1 = new System.Windows.Forms.Label();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.digitalOutputLabel0 = new System.Windows.Forms.Label();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.digitalInputsGroupBox = new System.Windows.Forms.GroupBox();
            this.digitalInputLabel15 = new System.Windows.Forms.Label();
            this.digitalInputLabel14 = new System.Windows.Forms.Label();
            this.digitalInputLabel13 = new System.Windows.Forms.Label();
            this.digitalInputLabel12 = new System.Windows.Forms.Label();
            this.digitalInputLabel11 = new System.Windows.Forms.Label();
            this.digitalInputLabel10 = new System.Windows.Forms.Label();
            this.digitalInputLabel9 = new System.Windows.Forms.Label();
            this.digitalInputLabel8 = new System.Windows.Forms.Label();
            this.digitalInputLabel7 = new System.Windows.Forms.Label();
            this.digitalInputLabel6 = new System.Windows.Forms.Label();
            this.digitalInputLabel5 = new System.Windows.Forms.Label();
            this.digitalInputLabel4 = new System.Windows.Forms.Label();
            this.digitalInputLabel3 = new System.Windows.Forms.Label();
            this.digitalInputLabel2 = new System.Windows.Forms.Label();
            this.digitalInputLabel1 = new System.Windows.Forms.Label();
            this.digitalInputLabel0 = new System.Windows.Forms.Label();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.analogInputsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputTrk)).BeginInit();
            this.digitalOutputsGroupBox.SuspendLayout();
            this.digitalInputsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.sensorInNumTxt);
            this.groupBox1.Controls.Add(this.digiOutNumTxt);
            this.groupBox1.Controls.Add(this.digiInNumTxt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.versionTxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.serialTxt);
            this.groupBox1.Controls.Add(this.nameTxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.attachedTxt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(261, 303);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "InterfaceKit Info";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Analog Inputs:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 235);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Digital Outputs:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Digital Inputs:";
            // 
            // sensorInNumTxt
            // 
            this.sensorInNumTxt.Location = new System.Drawing.Point(91, 264);
            this.sensorInNumTxt.Name = "sensorInNumTxt";
            this.sensorInNumTxt.ReadOnly = true;
            this.sensorInNumTxt.Size = new System.Drawing.Size(164, 20);
            this.sensorInNumTxt.TabIndex = 7;
            // 
            // digiOutNumTxt
            // 
            this.digiOutNumTxt.Location = new System.Drawing.Point(91, 232);
            this.digiOutNumTxt.Name = "digiOutNumTxt";
            this.digiOutNumTxt.ReadOnly = true;
            this.digiOutNumTxt.Size = new System.Drawing.Size(164, 20);
            this.digiOutNumTxt.TabIndex = 6;
            // 
            // digiInNumTxt
            // 
            this.digiInNumTxt.Location = new System.Drawing.Point(91, 198);
            this.digiInNumTxt.Name = "digiInNumTxt";
            this.digiInNumTxt.ReadOnly = true;
            this.digiInNumTxt.Size = new System.Drawing.Size(164, 20);
            this.digiInNumTxt.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Version:";
            // 
            // versionTxt
            // 
            this.versionTxt.Location = new System.Drawing.Point(91, 163);
            this.versionTxt.Name = "versionTxt";
            this.versionTxt.ReadOnly = true;
            this.versionTxt.Size = new System.Drawing.Size(164, 20);
            this.versionTxt.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Serial No.:";
            // 
            // serialTxt
            // 
            this.serialTxt.Location = new System.Drawing.Point(91, 128);
            this.serialTxt.Name = "serialTxt";
            this.serialTxt.ReadOnly = true;
            this.serialTxt.Size = new System.Drawing.Size(164, 20);
            this.serialTxt.TabIndex = 3;
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(91, 58);
            this.nameTxt.Multiline = true;
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.ReadOnly = true;
            this.nameTxt.Size = new System.Drawing.Size(164, 54);
            this.nameTxt.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name:";
            // 
            // attachedTxt
            // 
            this.attachedTxt.Location = new System.Drawing.Point(91, 24);
            this.attachedTxt.Name = "attachedTxt";
            this.attachedTxt.ReadOnly = true;
            this.attachedTxt.Size = new System.Drawing.Size(164, 20);
            this.attachedTxt.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attached:";
            // 
            // analogInputsGroupBox
            // 
            this.analogInputsGroupBox.Controls.Add(this.label9);
            this.analogInputsGroupBox.Controls.Add(this.sensorsButton);
            this.analogInputsGroupBox.Controls.Add(this.inputTrk);
            this.analogInputsGroupBox.Controls.Add(this.sensitivityTxt);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel7);
            this.analogInputsGroupBox.Controls.Add(this.label8);
            this.analogInputsGroupBox.Controls.Add(this.ratioChk);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel6);
            this.analogInputsGroupBox.Controls.Add(this.textBox8);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel5);
            this.analogInputsGroupBox.Controls.Add(this.textBox7);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel4);
            this.analogInputsGroupBox.Controls.Add(this.textBox6);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel3);
            this.analogInputsGroupBox.Controls.Add(this.textBox5);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel2);
            this.analogInputsGroupBox.Controls.Add(this.textBox4);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel1);
            this.analogInputsGroupBox.Controls.Add(this.textBox3);
            this.analogInputsGroupBox.Controls.Add(this.analogInputLabel0);
            this.analogInputsGroupBox.Controls.Add(this.textBox2);
            this.analogInputsGroupBox.Controls.Add(this.textBox1);
            this.analogInputsGroupBox.Location = new System.Drawing.Point(281, 154);
            this.analogInputsGroupBox.Name = "analogInputsGroupBox";
            this.analogInputsGroupBox.Size = new System.Drawing.Size(342, 138);
            this.analogInputsGroupBox.TabIndex = 16;
            this.analogInputsGroupBox.TabStop = false;
            this.analogInputsGroupBox.Text = "Analog In";
            // 
            // sensorsButton
            // 
            this.sensorsButton.Location = new System.Drawing.Point(249, 60);
            this.sensorsButton.Name = "sensorsButton";
            this.sensorsButton.Size = new System.Drawing.Size(75, 23);
            this.sensorsButton.TabIndex = 57;
            this.sensorsButton.Text = "Sensors";
            this.sensorsButton.UseVisualStyleBackColor = true;
            this.sensorsButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // inputTrk
            // 
            this.inputTrk.LargeChange = 25;
            this.inputTrk.Location = new System.Drawing.Point(96, 85);
            this.inputTrk.Maximum = 150;
            this.inputTrk.Name = "inputTrk";
            this.inputTrk.Size = new System.Drawing.Size(180, 45);
            this.inputTrk.TabIndex = 9;
            this.inputTrk.TickFrequency = 10;
            this.inputTrk.Scroll += new System.EventHandler(this.inputTrk_Scroll);
            // 
            // sensitivityTxt
            // 
            this.sensitivityTxt.Location = new System.Drawing.Point(282, 91);
            this.sensitivityTxt.Name = "sensitivityTxt";
            this.sensitivityTxt.ReadOnly = true;
            this.sensitivityTxt.Size = new System.Drawing.Size(42, 20);
            this.sensitivityTxt.TabIndex = 10;
            // 
            // analogInputLabel7
            // 
            this.analogInputLabel7.AutoSize = true;
            this.analogInputLabel7.Location = new System.Drawing.Point(300, 44);
            this.analogInputLabel7.Name = "analogInputLabel7";
            this.analogInputLabel7.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel7.TabIndex = 55;
            this.analogInputLabel7.Text = "7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Change Trigger:";
            // 
            // ratioChk
            // 
            this.ratioChk.AutoSize = true;
            this.ratioChk.Location = new System.Drawing.Point(18, 60);
            this.ratioChk.Name = "ratioChk";
            this.ratioChk.Size = new System.Drawing.Size(79, 17);
            this.ratioChk.TabIndex = 8;
            this.ratioChk.Text = "Ratiometric";
            this.ratioChk.UseVisualStyleBackColor = true;
            this.ratioChk.CheckedChanged += new System.EventHandler(this.ratioChk_CheckedChanged);
            // 
            // analogInputLabel6
            // 
            this.analogInputLabel6.AutoSize = true;
            this.analogInputLabel6.Location = new System.Drawing.Point(261, 44);
            this.analogInputLabel6.Name = "analogInputLabel6";
            this.analogInputLabel6.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel6.TabIndex = 54;
            this.analogInputLabel6.Text = "6";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(291, 21);
            this.textBox8.MaxLength = 3;
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(33, 20);
            this.textBox8.TabIndex = 7;
            // 
            // analogInputLabel5
            // 
            this.analogInputLabel5.AutoSize = true;
            this.analogInputLabel5.Location = new System.Drawing.Point(222, 44);
            this.analogInputLabel5.Name = "analogInputLabel5";
            this.analogInputLabel5.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel5.TabIndex = 53;
            this.analogInputLabel5.Text = "5";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(252, 21);
            this.textBox7.MaxLength = 3;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(33, 20);
            this.textBox7.TabIndex = 6;
            // 
            // analogInputLabel4
            // 
            this.analogInputLabel4.AutoSize = true;
            this.analogInputLabel4.Location = new System.Drawing.Point(183, 44);
            this.analogInputLabel4.Name = "analogInputLabel4";
            this.analogInputLabel4.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel4.TabIndex = 52;
            this.analogInputLabel4.Text = "4";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(213, 21);
            this.textBox6.MaxLength = 3;
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(33, 20);
            this.textBox6.TabIndex = 5;
            // 
            // analogInputLabel3
            // 
            this.analogInputLabel3.AutoSize = true;
            this.analogInputLabel3.Location = new System.Drawing.Point(144, 44);
            this.analogInputLabel3.Name = "analogInputLabel3";
            this.analogInputLabel3.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel3.TabIndex = 51;
            this.analogInputLabel3.Text = "3";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(174, 21);
            this.textBox5.MaxLength = 3;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(33, 20);
            this.textBox5.TabIndex = 4;
            // 
            // analogInputLabel2
            // 
            this.analogInputLabel2.AutoSize = true;
            this.analogInputLabel2.Location = new System.Drawing.Point(105, 44);
            this.analogInputLabel2.Name = "analogInputLabel2";
            this.analogInputLabel2.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel2.TabIndex = 50;
            this.analogInputLabel2.Text = "2";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(135, 21);
            this.textBox4.MaxLength = 3;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(33, 20);
            this.textBox4.TabIndex = 3;
            // 
            // analogInputLabel1
            // 
            this.analogInputLabel1.AutoSize = true;
            this.analogInputLabel1.Location = new System.Drawing.Point(66, 44);
            this.analogInputLabel1.Name = "analogInputLabel1";
            this.analogInputLabel1.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel1.TabIndex = 49;
            this.analogInputLabel1.Text = "1";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(96, 21);
            this.textBox3.MaxLength = 3;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(33, 20);
            this.textBox3.TabIndex = 2;
            // 
            // analogInputLabel0
            // 
            this.analogInputLabel0.AutoSize = true;
            this.analogInputLabel0.Location = new System.Drawing.Point(27, 44);
            this.analogInputLabel0.Name = "analogInputLabel0";
            this.analogInputLabel0.Size = new System.Drawing.Size(13, 13);
            this.analogInputLabel0.TabIndex = 48;
            this.analogInputLabel0.Text = "0";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(57, 21);
            this.textBox2.MaxLength = 3;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(33, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(18, 21);
            this.textBox1.MaxLength = 3;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(33, 20);
            this.textBox1.TabIndex = 0;
            // 
            // digitalOutputsGroupBox
            // 
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport0);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport1);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport2);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport3);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport4);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport5);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport6);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport7);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport8);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport9);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport10);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport11);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport12);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport13);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport14);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBoxReport15);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel15);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox17);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel14);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox18);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel13);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox19);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel12);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox20);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel11);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox21);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel10);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox22);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel9);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox23);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel8);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox24);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel7);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox25);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel6);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox26);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel5);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox27);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel4);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox28);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel3);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox29);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel2);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox30);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel1);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox31);
            this.digitalOutputsGroupBox.Controls.Add(this.digitalOutputLabel0);
            this.digitalOutputsGroupBox.Controls.Add(this.checkBox32);
            this.digitalOutputsGroupBox.Location = new System.Drawing.Point(280, 74);
            this.digitalOutputsGroupBox.Name = "digitalOutputsGroupBox";
            this.digitalOutputsGroupBox.Size = new System.Drawing.Size(342, 74);
            this.digitalOutputsGroupBox.TabIndex = 15;
            this.digitalOutputsGroupBox.TabStop = false;
            this.digitalOutputsGroupBox.Text = "Digital Out";
            // 
            // checkBoxReport0
            // 
            this.checkBoxReport0.AutoSize = true;
            this.checkBoxReport0.Enabled = false;
            this.checkBoxReport0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Fuchsia;
            this.checkBoxReport0.Location = new System.Drawing.Point(6, 20);
            this.checkBoxReport0.Name = "checkBoxReport0";
            this.checkBoxReport0.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport0.TabIndex = 63;
            this.checkBoxReport0.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport1
            // 
            this.checkBoxReport1.AutoSize = true;
            this.checkBoxReport1.Enabled = false;
            this.checkBoxReport1.Location = new System.Drawing.Point(27, 20);
            this.checkBoxReport1.Name = "checkBoxReport1";
            this.checkBoxReport1.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport1.TabIndex = 62;
            this.checkBoxReport1.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport2
            // 
            this.checkBoxReport2.AutoSize = true;
            this.checkBoxReport2.Enabled = false;
            this.checkBoxReport2.Location = new System.Drawing.Point(48, 20);
            this.checkBoxReport2.Name = "checkBoxReport2";
            this.checkBoxReport2.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport2.TabIndex = 61;
            this.checkBoxReport2.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport3
            // 
            this.checkBoxReport3.AutoSize = true;
            this.checkBoxReport3.Enabled = false;
            this.checkBoxReport3.Location = new System.Drawing.Point(69, 20);
            this.checkBoxReport3.Name = "checkBoxReport3";
            this.checkBoxReport3.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport3.TabIndex = 60;
            this.checkBoxReport3.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport4
            // 
            this.checkBoxReport4.AutoSize = true;
            this.checkBoxReport4.Enabled = false;
            this.checkBoxReport4.Location = new System.Drawing.Point(90, 20);
            this.checkBoxReport4.Name = "checkBoxReport4";
            this.checkBoxReport4.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport4.TabIndex = 59;
            this.checkBoxReport4.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport5
            // 
            this.checkBoxReport5.AutoSize = true;
            this.checkBoxReport5.Enabled = false;
            this.checkBoxReport5.Location = new System.Drawing.Point(111, 20);
            this.checkBoxReport5.Name = "checkBoxReport5";
            this.checkBoxReport5.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport5.TabIndex = 58;
            this.checkBoxReport5.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport6
            // 
            this.checkBoxReport6.AutoSize = true;
            this.checkBoxReport6.Enabled = false;
            this.checkBoxReport6.Location = new System.Drawing.Point(132, 20);
            this.checkBoxReport6.Name = "checkBoxReport6";
            this.checkBoxReport6.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport6.TabIndex = 57;
            this.checkBoxReport6.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport7
            // 
            this.checkBoxReport7.AutoSize = true;
            this.checkBoxReport7.Enabled = false;
            this.checkBoxReport7.Location = new System.Drawing.Point(153, 20);
            this.checkBoxReport7.Name = "checkBoxReport7";
            this.checkBoxReport7.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport7.TabIndex = 56;
            this.checkBoxReport7.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport8
            // 
            this.checkBoxReport8.AutoSize = true;
            this.checkBoxReport8.Enabled = false;
            this.checkBoxReport8.Location = new System.Drawing.Point(174, 20);
            this.checkBoxReport8.Name = "checkBoxReport8";
            this.checkBoxReport8.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport8.TabIndex = 55;
            this.checkBoxReport8.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport9
            // 
            this.checkBoxReport9.AutoSize = true;
            this.checkBoxReport9.Enabled = false;
            this.checkBoxReport9.Location = new System.Drawing.Point(195, 20);
            this.checkBoxReport9.Name = "checkBoxReport9";
            this.checkBoxReport9.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport9.TabIndex = 54;
            this.checkBoxReport9.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport10
            // 
            this.checkBoxReport10.AutoSize = true;
            this.checkBoxReport10.Enabled = false;
            this.checkBoxReport10.Location = new System.Drawing.Point(216, 20);
            this.checkBoxReport10.Name = "checkBoxReport10";
            this.checkBoxReport10.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport10.TabIndex = 53;
            this.checkBoxReport10.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport11
            // 
            this.checkBoxReport11.AutoSize = true;
            this.checkBoxReport11.Enabled = false;
            this.checkBoxReport11.Location = new System.Drawing.Point(237, 20);
            this.checkBoxReport11.Name = "checkBoxReport11";
            this.checkBoxReport11.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport11.TabIndex = 52;
            this.checkBoxReport11.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport12
            // 
            this.checkBoxReport12.AutoSize = true;
            this.checkBoxReport12.Enabled = false;
            this.checkBoxReport12.Location = new System.Drawing.Point(258, 20);
            this.checkBoxReport12.Name = "checkBoxReport12";
            this.checkBoxReport12.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport12.TabIndex = 51;
            this.checkBoxReport12.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport13
            // 
            this.checkBoxReport13.AutoSize = true;
            this.checkBoxReport13.Enabled = false;
            this.checkBoxReport13.Location = new System.Drawing.Point(279, 20);
            this.checkBoxReport13.Name = "checkBoxReport13";
            this.checkBoxReport13.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport13.TabIndex = 50;
            this.checkBoxReport13.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport14
            // 
            this.checkBoxReport14.AutoSize = true;
            this.checkBoxReport14.Enabled = false;
            this.checkBoxReport14.Location = new System.Drawing.Point(300, 20);
            this.checkBoxReport14.Name = "checkBoxReport14";
            this.checkBoxReport14.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport14.TabIndex = 49;
            this.checkBoxReport14.UseVisualStyleBackColor = true;
            // 
            // checkBoxReport15
            // 
            this.checkBoxReport15.AutoSize = true;
            this.checkBoxReport15.Enabled = false;
            this.checkBoxReport15.Location = new System.Drawing.Point(321, 20);
            this.checkBoxReport15.Name = "checkBoxReport15";
            this.checkBoxReport15.Size = new System.Drawing.Size(15, 14);
            this.checkBoxReport15.TabIndex = 48;
            this.checkBoxReport15.UseVisualStyleBackColor = true;
            // 
            // digitalOutputLabel15
            // 
            this.digitalOutputLabel15.AutoSize = true;
            this.digitalOutputLabel15.Location = new System.Drawing.Point(317, 53);
            this.digitalOutputLabel15.Name = "digitalOutputLabel15";
            this.digitalOutputLabel15.Size = new System.Drawing.Size(19, 13);
            this.digitalOutputLabel15.TabIndex = 47;
            this.digitalOutputLabel15.Text = "15";
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Enabled = false;
            this.checkBox17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Fuchsia;
            this.checkBox17.Location = new System.Drawing.Point(6, 36);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(15, 14);
            this.checkBox17.TabIndex = 1;
            this.checkBox17.Tag = "0";
            this.checkBox17.UseVisualStyleBackColor = true;
            this.checkBox17.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel14
            // 
            this.digitalOutputLabel14.AutoSize = true;
            this.digitalOutputLabel14.Location = new System.Drawing.Point(296, 53);
            this.digitalOutputLabel14.Name = "digitalOutputLabel14";
            this.digitalOutputLabel14.Size = new System.Drawing.Size(19, 13);
            this.digitalOutputLabel14.TabIndex = 46;
            this.digitalOutputLabel14.Text = "14";
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Enabled = false;
            this.checkBox18.Location = new System.Drawing.Point(27, 36);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(15, 14);
            this.checkBox18.TabIndex = 2;
            this.checkBox18.Tag = "1";
            this.checkBox18.UseVisualStyleBackColor = true;
            this.checkBox18.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel13
            // 
            this.digitalOutputLabel13.AutoSize = true;
            this.digitalOutputLabel13.Location = new System.Drawing.Point(275, 53);
            this.digitalOutputLabel13.Name = "digitalOutputLabel13";
            this.digitalOutputLabel13.Size = new System.Drawing.Size(19, 13);
            this.digitalOutputLabel13.TabIndex = 45;
            this.digitalOutputLabel13.Text = "13";
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Enabled = false;
            this.checkBox19.Location = new System.Drawing.Point(48, 36);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(15, 14);
            this.checkBox19.TabIndex = 3;
            this.checkBox19.Tag = "2";
            this.checkBox19.UseVisualStyleBackColor = true;
            this.checkBox19.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel12
            // 
            this.digitalOutputLabel12.AutoSize = true;
            this.digitalOutputLabel12.Location = new System.Drawing.Point(254, 53);
            this.digitalOutputLabel12.Name = "digitalOutputLabel12";
            this.digitalOutputLabel12.Size = new System.Drawing.Size(19, 13);
            this.digitalOutputLabel12.TabIndex = 44;
            this.digitalOutputLabel12.Text = "12";
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Enabled = false;
            this.checkBox20.Location = new System.Drawing.Point(69, 36);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(15, 14);
            this.checkBox20.TabIndex = 4;
            this.checkBox20.Tag = "3";
            this.checkBox20.UseVisualStyleBackColor = true;
            this.checkBox20.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel11
            // 
            this.digitalOutputLabel11.AutoSize = true;
            this.digitalOutputLabel11.Location = new System.Drawing.Point(233, 53);
            this.digitalOutputLabel11.Name = "digitalOutputLabel11";
            this.digitalOutputLabel11.Size = new System.Drawing.Size(19, 13);
            this.digitalOutputLabel11.TabIndex = 43;
            this.digitalOutputLabel11.Text = "11";
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Enabled = false;
            this.checkBox21.Location = new System.Drawing.Point(90, 36);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(15, 14);
            this.checkBox21.TabIndex = 5;
            this.checkBox21.Tag = "4";
            this.checkBox21.UseVisualStyleBackColor = true;
            this.checkBox21.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel10
            // 
            this.digitalOutputLabel10.AutoSize = true;
            this.digitalOutputLabel10.Location = new System.Drawing.Point(212, 53);
            this.digitalOutputLabel10.Name = "digitalOutputLabel10";
            this.digitalOutputLabel10.Size = new System.Drawing.Size(19, 13);
            this.digitalOutputLabel10.TabIndex = 42;
            this.digitalOutputLabel10.Text = "10";
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Enabled = false;
            this.checkBox22.Location = new System.Drawing.Point(111, 36);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(15, 14);
            this.checkBox22.TabIndex = 6;
            this.checkBox22.Tag = "5";
            this.checkBox22.UseVisualStyleBackColor = true;
            this.checkBox22.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel9
            // 
            this.digitalOutputLabel9.AutoSize = true;
            this.digitalOutputLabel9.Location = new System.Drawing.Point(195, 53);
            this.digitalOutputLabel9.Name = "digitalOutputLabel9";
            this.digitalOutputLabel9.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel9.TabIndex = 41;
            this.digitalOutputLabel9.Text = "9";
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Enabled = false;
            this.checkBox23.Location = new System.Drawing.Point(132, 36);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(15, 14);
            this.checkBox23.TabIndex = 7;
            this.checkBox23.Tag = "6";
            this.checkBox23.UseVisualStyleBackColor = true;
            this.checkBox23.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel8
            // 
            this.digitalOutputLabel8.AutoSize = true;
            this.digitalOutputLabel8.Location = new System.Drawing.Point(174, 53);
            this.digitalOutputLabel8.Name = "digitalOutputLabel8";
            this.digitalOutputLabel8.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel8.TabIndex = 40;
            this.digitalOutputLabel8.Text = "8";
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Enabled = false;
            this.checkBox24.Location = new System.Drawing.Point(153, 36);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(15, 14);
            this.checkBox24.TabIndex = 8;
            this.checkBox24.Tag = "7";
            this.checkBox24.UseVisualStyleBackColor = true;
            this.checkBox24.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel7
            // 
            this.digitalOutputLabel7.AutoSize = true;
            this.digitalOutputLabel7.Location = new System.Drawing.Point(153, 53);
            this.digitalOutputLabel7.Name = "digitalOutputLabel7";
            this.digitalOutputLabel7.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel7.TabIndex = 39;
            this.digitalOutputLabel7.Text = "7";
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Enabled = false;
            this.checkBox25.Location = new System.Drawing.Point(174, 36);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(15, 14);
            this.checkBox25.TabIndex = 9;
            this.checkBox25.Tag = "8";
            this.checkBox25.UseVisualStyleBackColor = true;
            this.checkBox25.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel6
            // 
            this.digitalOutputLabel6.AutoSize = true;
            this.digitalOutputLabel6.Location = new System.Drawing.Point(132, 53);
            this.digitalOutputLabel6.Name = "digitalOutputLabel6";
            this.digitalOutputLabel6.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel6.TabIndex = 38;
            this.digitalOutputLabel6.Text = "6";
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Enabled = false;
            this.checkBox26.Location = new System.Drawing.Point(195, 36);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(15, 14);
            this.checkBox26.TabIndex = 10;
            this.checkBox26.Tag = "9";
            this.checkBox26.UseVisualStyleBackColor = true;
            this.checkBox26.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel5
            // 
            this.digitalOutputLabel5.AutoSize = true;
            this.digitalOutputLabel5.Location = new System.Drawing.Point(111, 53);
            this.digitalOutputLabel5.Name = "digitalOutputLabel5";
            this.digitalOutputLabel5.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel5.TabIndex = 37;
            this.digitalOutputLabel5.Text = "5";
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Enabled = false;
            this.checkBox27.Location = new System.Drawing.Point(216, 36);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(15, 14);
            this.checkBox27.TabIndex = 11;
            this.checkBox27.Tag = "10";
            this.checkBox27.UseVisualStyleBackColor = true;
            this.checkBox27.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel4
            // 
            this.digitalOutputLabel4.AutoSize = true;
            this.digitalOutputLabel4.Location = new System.Drawing.Point(90, 53);
            this.digitalOutputLabel4.Name = "digitalOutputLabel4";
            this.digitalOutputLabel4.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel4.TabIndex = 36;
            this.digitalOutputLabel4.Text = "4";
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Enabled = false;
            this.checkBox28.Location = new System.Drawing.Point(237, 36);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(15, 14);
            this.checkBox28.TabIndex = 12;
            this.checkBox28.Tag = "11";
            this.checkBox28.UseVisualStyleBackColor = true;
            this.checkBox28.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel3
            // 
            this.digitalOutputLabel3.AutoSize = true;
            this.digitalOutputLabel3.Location = new System.Drawing.Point(69, 53);
            this.digitalOutputLabel3.Name = "digitalOutputLabel3";
            this.digitalOutputLabel3.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel3.TabIndex = 35;
            this.digitalOutputLabel3.Text = "3";
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Enabled = false;
            this.checkBox29.Location = new System.Drawing.Point(258, 36);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(15, 14);
            this.checkBox29.TabIndex = 13;
            this.checkBox29.Tag = "12";
            this.checkBox29.UseVisualStyleBackColor = true;
            this.checkBox29.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel2
            // 
            this.digitalOutputLabel2.AutoSize = true;
            this.digitalOutputLabel2.Location = new System.Drawing.Point(48, 53);
            this.digitalOutputLabel2.Name = "digitalOutputLabel2";
            this.digitalOutputLabel2.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel2.TabIndex = 34;
            this.digitalOutputLabel2.Text = "2";
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Enabled = false;
            this.checkBox30.Location = new System.Drawing.Point(279, 36);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(15, 14);
            this.checkBox30.TabIndex = 14;
            this.checkBox30.Tag = "13";
            this.checkBox30.UseVisualStyleBackColor = true;
            this.checkBox30.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel1
            // 
            this.digitalOutputLabel1.AutoSize = true;
            this.digitalOutputLabel1.Location = new System.Drawing.Point(27, 53);
            this.digitalOutputLabel1.Name = "digitalOutputLabel1";
            this.digitalOutputLabel1.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel1.TabIndex = 33;
            this.digitalOutputLabel1.Text = "1";
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Enabled = false;
            this.checkBox31.Location = new System.Drawing.Point(300, 36);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(15, 14);
            this.checkBox31.TabIndex = 15;
            this.checkBox31.Tag = "14";
            this.checkBox31.UseVisualStyleBackColor = true;
            this.checkBox31.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalOutputLabel0
            // 
            this.digitalOutputLabel0.AutoSize = true;
            this.digitalOutputLabel0.Location = new System.Drawing.Point(6, 53);
            this.digitalOutputLabel0.Name = "digitalOutputLabel0";
            this.digitalOutputLabel0.Size = new System.Drawing.Size(13, 13);
            this.digitalOutputLabel0.TabIndex = 32;
            this.digitalOutputLabel0.Text = "0";
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Enabled = false;
            this.checkBox32.Location = new System.Drawing.Point(321, 36);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(15, 14);
            this.checkBox32.TabIndex = 16;
            this.checkBox32.Tag = "15";
            this.checkBox32.UseVisualStyleBackColor = true;
            this.checkBox32.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // digitalInputsGroupBox
            // 
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel15);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel14);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel13);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel12);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel11);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel10);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel9);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel8);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel7);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel6);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel5);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel4);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel3);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel2);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel1);
            this.digitalInputsGroupBox.Controls.Add(this.digitalInputLabel0);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox16);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox15);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox14);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox13);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox12);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox11);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox10);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox9);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox8);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox7);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox6);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox5);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox4);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox3);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox2);
            this.digitalInputsGroupBox.Controls.Add(this.checkBox1);
            this.digitalInputsGroupBox.Location = new System.Drawing.Point(280, 12);
            this.digitalInputsGroupBox.Name = "digitalInputsGroupBox";
            this.digitalInputsGroupBox.Size = new System.Drawing.Size(342, 56);
            this.digitalInputsGroupBox.TabIndex = 14;
            this.digitalInputsGroupBox.TabStop = false;
            this.digitalInputsGroupBox.Text = "Digital In";
            // 
            // digitalInputLabel15
            // 
            this.digitalInputLabel15.AutoSize = true;
            this.digitalInputLabel15.Location = new System.Drawing.Point(317, 34);
            this.digitalInputLabel15.Name = "digitalInputLabel15";
            this.digitalInputLabel15.Size = new System.Drawing.Size(19, 13);
            this.digitalInputLabel15.TabIndex = 31;
            this.digitalInputLabel15.Text = "15";
            // 
            // digitalInputLabel14
            // 
            this.digitalInputLabel14.AutoSize = true;
            this.digitalInputLabel14.Location = new System.Drawing.Point(296, 34);
            this.digitalInputLabel14.Name = "digitalInputLabel14";
            this.digitalInputLabel14.Size = new System.Drawing.Size(19, 13);
            this.digitalInputLabel14.TabIndex = 30;
            this.digitalInputLabel14.Text = "14";
            // 
            // digitalInputLabel13
            // 
            this.digitalInputLabel13.AutoSize = true;
            this.digitalInputLabel13.Location = new System.Drawing.Point(275, 34);
            this.digitalInputLabel13.Name = "digitalInputLabel13";
            this.digitalInputLabel13.Size = new System.Drawing.Size(19, 13);
            this.digitalInputLabel13.TabIndex = 29;
            this.digitalInputLabel13.Text = "13";
            // 
            // digitalInputLabel12
            // 
            this.digitalInputLabel12.AutoSize = true;
            this.digitalInputLabel12.Location = new System.Drawing.Point(254, 34);
            this.digitalInputLabel12.Name = "digitalInputLabel12";
            this.digitalInputLabel12.Size = new System.Drawing.Size(19, 13);
            this.digitalInputLabel12.TabIndex = 28;
            this.digitalInputLabel12.Text = "12";
            // 
            // digitalInputLabel11
            // 
            this.digitalInputLabel11.AutoSize = true;
            this.digitalInputLabel11.Location = new System.Drawing.Point(233, 34);
            this.digitalInputLabel11.Name = "digitalInputLabel11";
            this.digitalInputLabel11.Size = new System.Drawing.Size(19, 13);
            this.digitalInputLabel11.TabIndex = 27;
            this.digitalInputLabel11.Text = "11";
            // 
            // digitalInputLabel10
            // 
            this.digitalInputLabel10.AutoSize = true;
            this.digitalInputLabel10.Location = new System.Drawing.Point(212, 34);
            this.digitalInputLabel10.Name = "digitalInputLabel10";
            this.digitalInputLabel10.Size = new System.Drawing.Size(19, 13);
            this.digitalInputLabel10.TabIndex = 26;
            this.digitalInputLabel10.Text = "10";
            // 
            // digitalInputLabel9
            // 
            this.digitalInputLabel9.AutoSize = true;
            this.digitalInputLabel9.Location = new System.Drawing.Point(195, 34);
            this.digitalInputLabel9.Name = "digitalInputLabel9";
            this.digitalInputLabel9.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel9.TabIndex = 25;
            this.digitalInputLabel9.Text = "9";
            // 
            // digitalInputLabel8
            // 
            this.digitalInputLabel8.AutoSize = true;
            this.digitalInputLabel8.Location = new System.Drawing.Point(174, 34);
            this.digitalInputLabel8.Name = "digitalInputLabel8";
            this.digitalInputLabel8.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel8.TabIndex = 24;
            this.digitalInputLabel8.Text = "8";
            // 
            // digitalInputLabel7
            // 
            this.digitalInputLabel7.AutoSize = true;
            this.digitalInputLabel7.Location = new System.Drawing.Point(153, 34);
            this.digitalInputLabel7.Name = "digitalInputLabel7";
            this.digitalInputLabel7.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel7.TabIndex = 23;
            this.digitalInputLabel7.Text = "7";
            // 
            // digitalInputLabel6
            // 
            this.digitalInputLabel6.AutoSize = true;
            this.digitalInputLabel6.Location = new System.Drawing.Point(132, 34);
            this.digitalInputLabel6.Name = "digitalInputLabel6";
            this.digitalInputLabel6.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel6.TabIndex = 22;
            this.digitalInputLabel6.Text = "6";
            // 
            // digitalInputLabel5
            // 
            this.digitalInputLabel5.AutoSize = true;
            this.digitalInputLabel5.Location = new System.Drawing.Point(111, 34);
            this.digitalInputLabel5.Name = "digitalInputLabel5";
            this.digitalInputLabel5.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel5.TabIndex = 21;
            this.digitalInputLabel5.Text = "5";
            // 
            // digitalInputLabel4
            // 
            this.digitalInputLabel4.AutoSize = true;
            this.digitalInputLabel4.Location = new System.Drawing.Point(90, 34);
            this.digitalInputLabel4.Name = "digitalInputLabel4";
            this.digitalInputLabel4.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel4.TabIndex = 20;
            this.digitalInputLabel4.Text = "4";
            // 
            // digitalInputLabel3
            // 
            this.digitalInputLabel3.AutoSize = true;
            this.digitalInputLabel3.Location = new System.Drawing.Point(69, 34);
            this.digitalInputLabel3.Name = "digitalInputLabel3";
            this.digitalInputLabel3.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel3.TabIndex = 19;
            this.digitalInputLabel3.Text = "3";
            // 
            // digitalInputLabel2
            // 
            this.digitalInputLabel2.AutoSize = true;
            this.digitalInputLabel2.Location = new System.Drawing.Point(48, 34);
            this.digitalInputLabel2.Name = "digitalInputLabel2";
            this.digitalInputLabel2.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel2.TabIndex = 18;
            this.digitalInputLabel2.Text = "2";
            // 
            // digitalInputLabel1
            // 
            this.digitalInputLabel1.AutoSize = true;
            this.digitalInputLabel1.Location = new System.Drawing.Point(27, 34);
            this.digitalInputLabel1.Name = "digitalInputLabel1";
            this.digitalInputLabel1.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel1.TabIndex = 17;
            this.digitalInputLabel1.Text = "1";
            // 
            // digitalInputLabel0
            // 
            this.digitalInputLabel0.AutoSize = true;
            this.digitalInputLabel0.Location = new System.Drawing.Point(6, 34);
            this.digitalInputLabel0.Name = "digitalInputLabel0";
            this.digitalInputLabel0.Size = new System.Drawing.Size(13, 13);
            this.digitalInputLabel0.TabIndex = 16;
            this.digitalInputLabel0.Text = "0";
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Enabled = false;
            this.checkBox16.Location = new System.Drawing.Point(321, 17);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(15, 14);
            this.checkBox16.TabIndex = 15;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Enabled = false;
            this.checkBox15.Location = new System.Drawing.Point(300, 17);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(15, 14);
            this.checkBox15.TabIndex = 14;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Enabled = false;
            this.checkBox14.Location = new System.Drawing.Point(279, 17);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(15, 14);
            this.checkBox14.TabIndex = 13;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Enabled = false;
            this.checkBox13.Location = new System.Drawing.Point(258, 17);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(15, 14);
            this.checkBox13.TabIndex = 12;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Enabled = false;
            this.checkBox12.Location = new System.Drawing.Point(237, 17);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(15, 14);
            this.checkBox12.TabIndex = 11;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Enabled = false;
            this.checkBox11.Location = new System.Drawing.Point(216, 17);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(15, 14);
            this.checkBox11.TabIndex = 10;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Enabled = false;
            this.checkBox10.Location = new System.Drawing.Point(195, 17);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(15, 14);
            this.checkBox10.TabIndex = 9;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Enabled = false;
            this.checkBox9.Location = new System.Drawing.Point(174, 17);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(15, 14);
            this.checkBox9.TabIndex = 8;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Enabled = false;
            this.checkBox8.Location = new System.Drawing.Point(153, 17);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 7;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Enabled = false;
            this.checkBox7.Location = new System.Drawing.Point(132, 17);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 6;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Enabled = false;
            this.checkBox6.Location = new System.Drawing.Point(111, 17);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Enabled = false;
            this.checkBox5.Location = new System.Drawing.Point(90, 17);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Enabled = false;
            this.checkBox4.Location = new System.Drawing.Point(69, 17);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Enabled = false;
            this.checkBox3.Location = new System.Drawing.Point(48, 17);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(27, 17);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.SystemColors.Control;
            this.checkBox1.Enabled = false;
            this.checkBox1.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checkBox1.Location = new System.Drawing.Point(6, 17);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 107);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "(Deadband)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 314);
            this.Controls.Add(this.analogInputsGroupBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.digitalOutputsGroupBox);
            this.Controls.Add(this.digitalInputsGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(642, 352);
            this.MinimumSize = new System.Drawing.Size(642, 352);
            this.Name = "Form1";
            this.Text = "InterfaceKit-full";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.analogInputsGroupBox.ResumeLayout(false);
            this.analogInputsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputTrk)).EndInit();
            this.digitalOutputsGroupBox.ResumeLayout(false);
            this.digitalOutputsGroupBox.PerformLayout();
            this.digitalInputsGroupBox.ResumeLayout(false);
            this.digitalInputsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox versionTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox serialTxt;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox attachedTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox sensorInNumTxt;
        private System.Windows.Forms.TextBox digiOutNumTxt;
        private System.Windows.Forms.TextBox digiInNumTxt;
        private System.Windows.Forms.GroupBox analogInputsGroupBox;
        private System.Windows.Forms.Button sensorsButton;
        private System.Windows.Forms.TrackBar inputTrk;
        private System.Windows.Forms.TextBox sensitivityTxt;
        private System.Windows.Forms.Label analogInputLabel7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox ratioChk;
        private System.Windows.Forms.Label analogInputLabel6;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label analogInputLabel5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label analogInputLabel4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label analogInputLabel3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label analogInputLabel2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label analogInputLabel1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label analogInputLabel0;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox digitalOutputsGroupBox;
        private System.Windows.Forms.CheckBox checkBoxReport0;
        private System.Windows.Forms.CheckBox checkBoxReport1;
        private System.Windows.Forms.CheckBox checkBoxReport2;
        private System.Windows.Forms.CheckBox checkBoxReport3;
        private System.Windows.Forms.CheckBox checkBoxReport4;
        private System.Windows.Forms.CheckBox checkBoxReport5;
        private System.Windows.Forms.CheckBox checkBoxReport6;
        private System.Windows.Forms.CheckBox checkBoxReport7;
        private System.Windows.Forms.CheckBox checkBoxReport8;
        private System.Windows.Forms.CheckBox checkBoxReport9;
        private System.Windows.Forms.CheckBox checkBoxReport10;
        private System.Windows.Forms.CheckBox checkBoxReport11;
        private System.Windows.Forms.CheckBox checkBoxReport12;
        private System.Windows.Forms.CheckBox checkBoxReport13;
        private System.Windows.Forms.CheckBox checkBoxReport14;
        private System.Windows.Forms.CheckBox checkBoxReport15;
        private System.Windows.Forms.Label digitalOutputLabel15;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.Label digitalOutputLabel14;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.Label digitalOutputLabel13;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.Label digitalOutputLabel12;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.Label digitalOutputLabel11;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.Label digitalOutputLabel10;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.Label digitalOutputLabel9;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.Label digitalOutputLabel8;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.Label digitalOutputLabel7;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.Label digitalOutputLabel6;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.Label digitalOutputLabel5;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.Label digitalOutputLabel4;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.Label digitalOutputLabel3;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.Label digitalOutputLabel2;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.Label digitalOutputLabel1;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.Label digitalOutputLabel0;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.GroupBox digitalInputsGroupBox;
        private System.Windows.Forms.Label digitalInputLabel15;
        private System.Windows.Forms.Label digitalInputLabel14;
        private System.Windows.Forms.Label digitalInputLabel13;
        private System.Windows.Forms.Label digitalInputLabel12;
        private System.Windows.Forms.Label digitalInputLabel11;
        private System.Windows.Forms.Label digitalInputLabel10;
        private System.Windows.Forms.Label digitalInputLabel9;
        private System.Windows.Forms.Label digitalInputLabel8;
        private System.Windows.Forms.Label digitalInputLabel7;
        private System.Windows.Forms.Label digitalInputLabel6;
        private System.Windows.Forms.Label digitalInputLabel5;
        private System.Windows.Forms.Label digitalInputLabel4;
        private System.Windows.Forms.Label digitalInputLabel3;
        private System.Windows.Forms.Label digitalInputLabel2;
        private System.Windows.Forms.Label digitalInputLabel1;
        private System.Windows.Forms.Label digitalInputLabel0;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label9;
    }
}

