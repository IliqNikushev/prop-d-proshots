namespace InterfaceKit_full
{
    partial class AdvancedSensorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sensorBox8 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox7 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox6 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox5 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox4 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox3 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox2 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.sensorBox1 = new InterfaceKit_full.SensorExamples.SensorBox();
            this.SuspendLayout();
            // 
            // sensorBox8
            // 
            this.sensorBox8.Location = new System.Drawing.Point(353, 327);
            this.sensorBox8.Name = "sensorBox8";
            this.sensorBox8.Size = new System.Drawing.Size(335, 99);
            this.sensorBox8.TabIndex = 8;
            // 
            // sensorBox7
            // 
            this.sensorBox7.Location = new System.Drawing.Point(12, 327);
            this.sensorBox7.Name = "sensorBox7";
            this.sensorBox7.Size = new System.Drawing.Size(335, 99);
            this.sensorBox7.TabIndex = 7;
            // 
            // sensorBox6
            // 
            this.sensorBox6.Location = new System.Drawing.Point(353, 222);
            this.sensorBox6.Name = "sensorBox6";
            this.sensorBox6.Size = new System.Drawing.Size(335, 99);
            this.sensorBox6.TabIndex = 6;
            // 
            // sensorBox5
            // 
            this.sensorBox5.Location = new System.Drawing.Point(12, 222);
            this.sensorBox5.Name = "sensorBox5";
            this.sensorBox5.Size = new System.Drawing.Size(335, 99);
            this.sensorBox5.TabIndex = 5;
            // 
            // sensorBox4
            // 
            this.sensorBox4.Location = new System.Drawing.Point(353, 117);
            this.sensorBox4.Name = "sensorBox4";
            this.sensorBox4.Size = new System.Drawing.Size(335, 99);
            this.sensorBox4.TabIndex = 4;
            // 
            // sensorBox3
            // 
            this.sensorBox3.Location = new System.Drawing.Point(12, 117);
            this.sensorBox3.Name = "sensorBox3";
            this.sensorBox3.Size = new System.Drawing.Size(335, 99);
            this.sensorBox3.TabIndex = 3;
            // 
            // sensorBox2
            // 
            this.sensorBox2.Location = new System.Drawing.Point(353, 12);
            this.sensorBox2.Name = "sensorBox2";
            this.sensorBox2.Size = new System.Drawing.Size(335, 99);
            this.sensorBox2.TabIndex = 2;
            // 
            // sensorBox1
            // 
            this.sensorBox1.Location = new System.Drawing.Point(12, 12);
            this.sensorBox1.Name = "sensorBox1";
            this.sensorBox1.Size = new System.Drawing.Size(335, 99);
            this.sensorBox1.TabIndex = 1;
            this.sensorBox1.Load += new System.EventHandler(this.sensorBox1_Load);
            // 
            // AdvancedSensorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 436);
            this.Controls.Add(this.sensorBox8);
            this.Controls.Add(this.sensorBox7);
            this.Controls.Add(this.sensorBox6);
            this.Controls.Add(this.sensorBox5);
            this.Controls.Add(this.sensorBox4);
            this.Controls.Add(this.sensorBox3);
            this.Controls.Add(this.sensorBox2);
            this.Controls.Add(this.sensorBox1);
            this.MaximumSize = new System.Drawing.Size(708, 470);
            this.MinimumSize = new System.Drawing.Size(708, 470);
            this.Name = "AdvancedSensorForm";
            this.Text = "Advanced Sensor Form";
            this.Load += new System.EventHandler(this.AdvancedSensorForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private InterfaceKit_full.SensorExamples.SensorBox sensorBox1;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox2;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox3;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox4;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox5;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox6;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox7;
        private InterfaceKit_full.SensorExamples.SensorBox sensorBox8;


    }
}