namespace Bridge_full
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numBridgesTxt = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.versiontxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.serialTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.attachedTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataRateBox = new System.Windows.Forms.TextBox();
            this.formulaTxt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.gainCmb = new System.Windows.Forms.ComboBox();
            this.startBut = new System.Windows.Forms.Button();
            this.set2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.set1 = new System.Windows.Forms.Button();
            this.convertTxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bridgeCmb = new System.Windows.Forms.ComboBox();
            this.value1txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.value2txt = new System.Windows.Forms.TextBox();
            this.valueTxt = new System.Windows.Forms.TextBox();
            this.enCheck = new System.Windows.Forms.CheckBox();
            this.dataRateBar = new System.Windows.Forms.TrackBar();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRateBar)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numBridgesTxt);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.versiontxt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.serialTxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nameTxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.attachedTxt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(269, 193);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bridge Details";
            // 
            // numBridgesTxt
            // 
            this.numBridgesTxt.Location = new System.Drawing.Point(91, 163);
            this.numBridgesTxt.Name = "numBridgesTxt";
            this.numBridgesTxt.ReadOnly = true;
            this.numBridgesTxt.Size = new System.Drawing.Size(163, 20);
            this.numBridgesTxt.TabIndex = 17;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 166);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 13);
            this.label24.TabIndex = 16;
            this.label24.Text = "# Bridges:";
            // 
            // versiontxt
            // 
            this.versiontxt.Location = new System.Drawing.Point(91, 137);
            this.versiontxt.Name = "versiontxt";
            this.versiontxt.ReadOnly = true;
            this.versiontxt.Size = new System.Drawing.Size(163, 20);
            this.versiontxt.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Version:";
            // 
            // serialTxt
            // 
            this.serialTxt.Location = new System.Drawing.Point(91, 111);
            this.serialTxt.Name = "serialTxt";
            this.serialTxt.ReadOnly = true;
            this.serialTxt.Size = new System.Drawing.Size(163, 20);
            this.serialTxt.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Serial No.:";
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(91, 50);
            this.nameTxt.Multiline = true;
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.ReadOnly = true;
            this.nameTxt.Size = new System.Drawing.Size(163, 48);
            this.nameTxt.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Name:";
            // 
            // attachedTxt
            // 
            this.attachedTxt.Location = new System.Drawing.Point(91, 19);
            this.attachedTxt.Name = "attachedTxt";
            this.attachedTxt.ReadOnly = true;
            this.attachedTxt.Size = new System.Drawing.Size(163, 20);
            this.attachedTxt.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Attached:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dataRateBox);
            this.groupBox2.Controls.Add(this.formulaTxt);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.gainCmb);
            this.groupBox2.Controls.Add(this.startBut);
            this.groupBox2.Controls.Add(this.set2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.set1);
            this.groupBox2.Controls.Add(this.convertTxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.bridgeCmb);
            this.groupBox2.Controls.Add(this.value1txt);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.value2txt);
            this.groupBox2.Controls.Add(this.valueTxt);
            this.groupBox2.Controls.Add(this.enCheck);
            this.groupBox2.Controls.Add(this.dataRateBar);
            this.groupBox2.Location = new System.Drawing.Point(12, 213);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(270, 360);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bridge Data";
            // 
            // dataRateBox
            // 
            this.dataRateBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dataRateBox.Location = new System.Drawing.Point(205, 319);
            this.dataRateBox.Name = "dataRateBox";
            this.dataRateBox.ReadOnly = true;
            this.dataRateBox.Size = new System.Drawing.Size(59, 20);
            this.dataRateBox.TabIndex = 90;
            // 
            // formulaTxt
            // 
            this.formulaTxt.Location = new System.Drawing.Point(96, 279);
            this.formulaTxt.Name = "formulaTxt";
            this.formulaTxt.ReadOnly = true;
            this.formulaTxt.Size = new System.Drawing.Size(128, 20);
            this.formulaTxt.TabIndex = 89;
            this.formulaTxt.Text = "y = m*x + b";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 322);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 13);
            this.label13.TabIndex = 71;
            this.label13.Text = "Data Rate: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 282);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 88;
            this.label10.Text = "Formula:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(136, 70);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 13);
            this.label14.TabIndex = 57;
            this.label14.Text = "Gain:";
            // 
            // gainCmb
            // 
            this.gainCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gainCmb.Enabled = false;
            this.gainCmb.FormattingEnabled = true;
            this.gainCmb.Items.AddRange(new object[] {
            "1",
            "8",
            "16",
            "32",
            "64",
            "128"});
            this.gainCmb.Location = new System.Drawing.Point(174, 67);
            this.gainCmb.Name = "gainCmb";
            this.gainCmb.Size = new System.Drawing.Size(81, 21);
            this.gainCmb.TabIndex = 58;
            this.gainCmb.SelectedIndexChanged += new System.EventHandler(this.gainCmb_SelectedIndexChanged);
            // 
            // startBut
            // 
            this.startBut.Enabled = false;
            this.startBut.Location = new System.Drawing.Point(59, 187);
            this.startBut.Name = "startBut";
            this.startBut.Size = new System.Drawing.Size(141, 28);
            this.startBut.TabIndex = 87;
            this.startBut.Text = "Start Calibration";
            this.startBut.UseVisualStyleBackColor = true;
            this.startBut.Click += new System.EventHandler(this.startBut_Click);
            // 
            // set2
            // 
            this.set2.Enabled = false;
            this.set2.Location = new System.Drawing.Point(179, 251);
            this.set2.Name = "set2";
            this.set2.Size = new System.Drawing.Size(45, 23);
            this.set2.TabIndex = 86;
            this.set2.Text = "Set";
            this.set2.UseVisualStyleBackColor = true;
            this.set2.Click += new System.EventHandler(this.set2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(215, 26);
            this.label7.TabIndex = 80;
            this.label7.Text = "Use the calibration function below to create\r\na unit conversion factor for the br" +
                "idge value.\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 79;
            this.label6.Text = "Converted Value:";
            // 
            // set1
            // 
            this.set1.Enabled = false;
            this.set1.Location = new System.Drawing.Point(179, 225);
            this.set1.Name = "set1";
            this.set1.Size = new System.Drawing.Size(45, 23);
            this.set1.TabIndex = 85;
            this.set1.Text = "Set";
            this.set1.UseVisualStyleBackColor = true;
            this.set1.Click += new System.EventHandler(this.set1_Click);
            // 
            // convertTxt
            // 
            this.convertTxt.Location = new System.Drawing.Point(123, 120);
            this.convertTxt.Name = "convertTxt";
            this.convertTxt.ReadOnly = true;
            this.convertTxt.Size = new System.Drawing.Size(132, 20);
            this.convertTxt.TabIndex = 78;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 77;
            this.label5.Text = "Choose Bridge:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 84;
            this.label9.Text = "Value 2:";
            // 
            // bridgeCmb
            // 
            this.bridgeCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.bridgeCmb.Enabled = false;
            this.bridgeCmb.FormattingEnabled = true;
            this.bridgeCmb.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.bridgeCmb.Location = new System.Drawing.Point(153, 19);
            this.bridgeCmb.Name = "bridgeCmb";
            this.bridgeCmb.Size = new System.Drawing.Size(50, 21);
            this.bridgeCmb.TabIndex = 76;
            this.bridgeCmb.SelectedIndexChanged += new System.EventHandler(this.bridgeCmb_SelectedIndexChanged);
            // 
            // value1txt
            // 
            this.value1txt.Location = new System.Drawing.Point(96, 227);
            this.value1txt.Name = "value1txt";
            this.value1txt.ReadOnly = true;
            this.value1txt.Size = new System.Drawing.Size(77, 20);
            this.value1txt.TabIndex = 81;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 230);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 83;
            this.label8.Text = "Value 1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 13);
            this.label11.TabIndex = 63;
            this.label11.Text = "Bridge Value (mV/V):";
            // 
            // value2txt
            // 
            this.value2txt.Location = new System.Drawing.Point(96, 253);
            this.value2txt.Name = "value2txt";
            this.value2txt.ReadOnly = true;
            this.value2txt.Size = new System.Drawing.Size(77, 20);
            this.value2txt.TabIndex = 82;
            // 
            // valueTxt
            // 
            this.valueTxt.Location = new System.Drawing.Point(123, 94);
            this.valueTxt.Name = "valueTxt";
            this.valueTxt.ReadOnly = true;
            this.valueTxt.Size = new System.Drawing.Size(132, 20);
            this.valueTxt.TabIndex = 61;
            // 
            // enCheck
            // 
            this.enCheck.AutoSize = true;
            this.enCheck.Enabled = false;
            this.enCheck.Location = new System.Drawing.Point(14, 69);
            this.enCheck.Name = "enCheck";
            this.enCheck.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.enCheck.Size = new System.Drawing.Size(65, 17);
            this.enCheck.TabIndex = 59;
            this.enCheck.Text = "Enabled";
            this.enCheck.UseVisualStyleBackColor = true;
            this.enCheck.CheckedChanged += new System.EventHandler(this.enCheck_CheckedChanged);
            // 
            // dataRateBar
            // 
            this.dataRateBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataRateBar.Enabled = false;
            this.dataRateBar.LargeChange = 4;
            this.dataRateBar.Location = new System.Drawing.Point(67, 313);
            this.dataRateBar.Maximum = 125;
            this.dataRateBar.Minimum = 1;
            this.dataRateBar.Name = "dataRateBar";
            this.dataRateBar.Size = new System.Drawing.Size(132, 45);
            this.dataRateBar.TabIndex = 72;
            this.dataRateBar.TickFrequency = 5;
            this.dataRateBar.Value = 8;
            this.dataRateBar.Scroll += new System.EventHandler(this.dataRateBar_Scroll);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(93, 71);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 13);
            this.label15.TabIndex = 63;
            this.label15.Text = "Bridge Value:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(80, 97);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 13);
            this.label17.TabIndex = 62;
            this.label17.Text = "Change Trigger:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(169, 68);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(84, 20);
            this.textBox6.TabIndex = 61;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(169, 94);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(84, 20);
            this.textBox7.TabIndex = 60;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(116, 18);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkBox3.Size = new System.Drawing.Size(71, 17);
            this.checkBox3.TabIndex = 59;
            this.checkBox3.Text = "Enabled: ";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(131, 44);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 13);
            this.label19.TabIndex = 57;
            this.label19.Text = "Gain:";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "1",
            "8",
            "16",
            "32",
            "64",
            "128"});
            this.comboBox4.Location = new System.Drawing.Point(169, 41);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(84, 21);
            this.comboBox4.TabIndex = 58;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(295, 585);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MinimumSize = new System.Drawing.Size(303, 427);
            this.Name = "Form1";
            this.Text = "Bridge-full";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRateBar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox versiontxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox serialTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox attachedTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox valueTxt;
        private System.Windows.Forms.CheckBox enCheck;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox gainCmb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox numBridgesTxt;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox bridgeCmb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox convertTxt;
        private System.Windows.Forms.Button set2;
        private System.Windows.Forms.Button set1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox value2txt;
        private System.Windows.Forms.TextBox value1txt;
        private System.Windows.Forms.TextBox formulaTxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button startBut;
        private System.Windows.Forms.TrackBar dataRateBar;
        private System.Windows.Forms.TextBox dataRateBox;
    }
}

