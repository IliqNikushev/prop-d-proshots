namespace TextLCD_full
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.versiontxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.serialTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.attachedTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.brightnessTrkBr = new Dotnetrix.Controls.TrackBar();
            this.contrastTrkBr = new Dotnetrix.Controls.TrackBar();
            this.label10 = new System.Windows.Forms.Label();
            this.brightnessLbl = new System.Windows.Forms.Label();
            this.cursorBlinkChk = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cursorChk = new System.Windows.Forms.CheckBox();
            this.backlightChk = new System.Windows.Forms.CheckBox();
            this.screenCmb = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.row3 = new System.Windows.Forms.TextBox();
            this.row2 = new System.Windows.Forms.TextBox();
            this.row1 = new System.Windows.Forms.TextBox();
            this.row0 = new System.Windows.Forms.TextBox();
            this.screenSizeCmb = new System.Windows.Forms.ComboBox();
            this.initButton = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.previewPic = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.customCharScreenCmb = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.memoryLocCmb = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.storeCustom = new System.Windows.Forms.Button();
            this.pictureBox0 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.brightnessTrkBr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contrastTrkBr)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.previewPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.versiontxt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.serialTxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nameTxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.attachedTxt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 188);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LCD Details";
            // 
            // versiontxt
            // 
            this.versiontxt.Location = new System.Drawing.Point(67, 142);
            this.versiontxt.Name = "versiontxt";
            this.versiontxt.ReadOnly = true;
            this.versiontxt.Size = new System.Drawing.Size(163, 20);
            this.versiontxt.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Version:";
            // 
            // serialTxt
            // 
            this.serialTxt.Location = new System.Drawing.Point(67, 111);
            this.serialTxt.Name = "serialTxt";
            this.serialTxt.ReadOnly = true;
            this.serialTxt.Size = new System.Drawing.Size(163, 20);
            this.serialTxt.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Serial No.:";
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(67, 50);
            this.nameTxt.Multiline = true;
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.ReadOnly = true;
            this.nameTxt.Size = new System.Drawing.Size(163, 48);
            this.nameTxt.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name:";
            // 
            // attachedTxt
            // 
            this.attachedTxt.Location = new System.Drawing.Point(67, 19);
            this.attachedTxt.Name = "attachedTxt";
            this.attachedTxt.ReadOnly = true;
            this.attachedTxt.Size = new System.Drawing.Size(163, 20);
            this.attachedTxt.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attached:";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 206);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(274, 326);
            this.tabControl1.TabIndex = 59;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.brightnessTrkBr);
            this.tabPage1.Controls.Add(this.contrastTrkBr);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.brightnessLbl);
            this.tabPage1.Controls.Add(this.cursorBlinkChk);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.cursorChk);
            this.tabPage1.Controls.Add(this.backlightChk);
            this.tabPage1.Controls.Add(this.screenCmb);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.row3);
            this.tabPage1.Controls.Add(this.row2);
            this.tabPage1.Controls.Add(this.row1);
            this.tabPage1.Controls.Add(this.row0);
            this.tabPage1.Controls.Add(this.screenSizeCmb);
            this.tabPage1.Controls.Add(this.initButton);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(266, 300);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "LCD Display";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // brightnessTrkBr
            // 
            this.brightnessTrkBr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.brightnessTrkBr.Enabled = false;
            this.brightnessTrkBr.Location = new System.Drawing.Point(61, 256);
            this.brightnessTrkBr.Maximum = 255;
            this.brightnessTrkBr.Name = "brightnessTrkBr";
            this.brightnessTrkBr.Size = new System.Drawing.Size(195, 45);
            this.brightnessTrkBr.TabIndex = 101;
            this.brightnessTrkBr.TickFrequency = 10;
            this.brightnessTrkBr.Visible = false;
            this.brightnessTrkBr.Scroll += new System.EventHandler(this.brightnessTrkBr_Scroll);
            // 
            // contrastTrkBr
            // 
            this.contrastTrkBr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.contrastTrkBr.Enabled = false;
            this.contrastTrkBr.Location = new System.Drawing.Point(61, 224);
            this.contrastTrkBr.Maximum = 255;
            this.contrastTrkBr.Name = "contrastTrkBr";
            this.contrastTrkBr.Size = new System.Drawing.Size(195, 45);
            this.contrastTrkBr.TabIndex = 100;
            this.contrastTrkBr.TickFrequency = 10;
            this.contrastTrkBr.Scroll += new System.EventHandler(this.contrastTrkBr_Scroll);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 59);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 13);
            this.label10.TabIndex = 99;
            this.label10.Text = "Screen Size:";
            // 
            // brightnessLbl
            // 
            this.brightnessLbl.AutoSize = true;
            this.brightnessLbl.Location = new System.Drawing.Point(6, 261);
            this.brightnessLbl.Name = "brightnessLbl";
            this.brightnessLbl.Size = new System.Drawing.Size(59, 13);
            this.brightnessLbl.TabIndex = 97;
            this.brightnessLbl.Text = "Brightness:";
            this.brightnessLbl.Visible = false;
            // 
            // cursorBlinkChk
            // 
            this.cursorBlinkChk.AutoSize = true;
            this.cursorBlinkChk.Enabled = false;
            this.cursorBlinkChk.Location = new System.Drawing.Point(180, 201);
            this.cursorBlinkChk.Name = "cursorBlinkChk";
            this.cursorBlinkChk.Size = new System.Drawing.Size(82, 17);
            this.cursorBlinkChk.TabIndex = 95;
            this.cursorBlinkChk.Text = "Cursor Blink";
            this.cursorBlinkChk.UseVisualStyleBackColor = true;
            this.cursorBlinkChk.CheckedChanged += new System.EventHandler(this.cursorBlinkChk_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 228);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 13);
            this.label12.TabIndex = 93;
            this.label12.Text = "Contrast:";
            // 
            // cursorChk
            // 
            this.cursorChk.AutoSize = true;
            this.cursorChk.Enabled = false;
            this.cursorChk.Location = new System.Drawing.Point(99, 201);
            this.cursorChk.Name = "cursorChk";
            this.cursorChk.Size = new System.Drawing.Size(56, 17);
            this.cursorChk.TabIndex = 92;
            this.cursorChk.Text = "Cursor";
            this.cursorChk.UseVisualStyleBackColor = true;
            this.cursorChk.CheckedChanged += new System.EventHandler(this.cursorChk_CheckedChanged);
            // 
            // backlightChk
            // 
            this.backlightChk.AutoSize = true;
            this.backlightChk.Enabled = false;
            this.backlightChk.Location = new System.Drawing.Point(9, 201);
            this.backlightChk.Name = "backlightChk";
            this.backlightChk.Size = new System.Drawing.Size(70, 17);
            this.backlightChk.TabIndex = 91;
            this.backlightChk.Text = "Backlight";
            this.backlightChk.UseVisualStyleBackColor = true;
            this.backlightChk.CheckedChanged += new System.EventHandler(this.backlightChk_CheckedChanged);
            // 
            // screenCmb
            // 
            this.screenCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.screenCmb.Enabled = false;
            this.screenCmb.FormattingEnabled = true;
            this.screenCmb.Location = new System.Drawing.Point(157, 10);
            this.screenCmb.Name = "screenCmb";
            this.screenCmb.Size = new System.Drawing.Size(54, 21);
            this.screenCmb.TabIndex = 89;
            this.screenCmb.SelectedIndexChanged += new System.EventHandler(this.screenCmb_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(68, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 90;
            this.label9.Text = "Choose Screen:";
            // 
            // row3
            // 
            this.row3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.row3.Enabled = false;
            this.row3.Location = new System.Drawing.Point(9, 162);
            this.row3.Name = "row3";
            this.row3.Size = new System.Drawing.Size(247, 20);
            this.row3.TabIndex = 85;
            this.row3.Tag = "3";
            this.row3.TextChanged += new System.EventHandler(this.row_TextChanged);
            // 
            // row2
            // 
            this.row2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.row2.Enabled = false;
            this.row2.Location = new System.Drawing.Point(9, 136);
            this.row2.Name = "row2";
            this.row2.Size = new System.Drawing.Size(247, 20);
            this.row2.TabIndex = 84;
            this.row2.Tag = "2";
            this.row2.TextChanged += new System.EventHandler(this.row_TextChanged);
            // 
            // row1
            // 
            this.row1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.row1.Enabled = false;
            this.row1.Location = new System.Drawing.Point(9, 110);
            this.row1.Name = "row1";
            this.row1.Size = new System.Drawing.Size(247, 20);
            this.row1.TabIndex = 83;
            this.row1.Tag = "1";
            this.row1.TextChanged += new System.EventHandler(this.row_TextChanged);
            // 
            // row0
            // 
            this.row0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.row0.Enabled = false;
            this.row0.Location = new System.Drawing.Point(9, 84);
            this.row0.Name = "row0";
            this.row0.Size = new System.Drawing.Size(247, 20);
            this.row0.TabIndex = 82;
            this.row0.Tag = "0";
            this.row0.TextChanged += new System.EventHandler(this.row_TextChanged);
            // 
            // screenSizeCmb
            // 
            this.screenSizeCmb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.screenSizeCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.screenSizeCmb.Enabled = false;
            this.screenSizeCmb.FormattingEnabled = true;
            this.screenSizeCmb.Location = new System.Drawing.Point(79, 56);
            this.screenSizeCmb.Name = "screenSizeCmb";
            this.screenSizeCmb.Size = new System.Drawing.Size(108, 21);
            this.screenSizeCmb.TabIndex = 81;
            this.screenSizeCmb.SelectedIndexChanged += new System.EventHandler(this.screenSizeCmb_SelectedIndexChanged);
            // 
            // initButton
            // 
            this.initButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.initButton.Enabled = false;
            this.initButton.Location = new System.Drawing.Point(193, 54);
            this.initButton.Name = "initButton";
            this.initButton.Size = new System.Drawing.Size(63, 25);
            this.initButton.TabIndex = 80;
            this.initButton.Text = "Initialize";
            this.initButton.UseVisualStyleBackColor = true;
            this.initButton.Visible = false;
            this.initButton.Click += new System.EventHandler(this.initButton_Click_1);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Transparent;
            this.tabPage4.Controls.Add(this.previewPic);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.customCharScreenCmb);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.memoryLocCmb);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.textBox10);
            this.tabPage4.Controls.Add(this.textBox9);
            this.tabPage4.Controls.Add(this.pictureBox35);
            this.tabPage4.Controls.Add(this.pictureBox36);
            this.tabPage4.Controls.Add(this.pictureBox37);
            this.tabPage4.Controls.Add(this.pictureBox38);
            this.tabPage4.Controls.Add(this.pictureBox39);
            this.tabPage4.Controls.Add(this.pictureBox30);
            this.tabPage4.Controls.Add(this.pictureBox31);
            this.tabPage4.Controls.Add(this.pictureBox32);
            this.tabPage4.Controls.Add(this.pictureBox33);
            this.tabPage4.Controls.Add(this.pictureBox34);
            this.tabPage4.Controls.Add(this.pictureBox25);
            this.tabPage4.Controls.Add(this.pictureBox26);
            this.tabPage4.Controls.Add(this.pictureBox27);
            this.tabPage4.Controls.Add(this.pictureBox28);
            this.tabPage4.Controls.Add(this.pictureBox29);
            this.tabPage4.Controls.Add(this.pictureBox20);
            this.tabPage4.Controls.Add(this.pictureBox21);
            this.tabPage4.Controls.Add(this.pictureBox22);
            this.tabPage4.Controls.Add(this.pictureBox23);
            this.tabPage4.Controls.Add(this.pictureBox24);
            this.tabPage4.Controls.Add(this.pictureBox15);
            this.tabPage4.Controls.Add(this.pictureBox16);
            this.tabPage4.Controls.Add(this.pictureBox17);
            this.tabPage4.Controls.Add(this.pictureBox18);
            this.tabPage4.Controls.Add(this.pictureBox19);
            this.tabPage4.Controls.Add(this.pictureBox10);
            this.tabPage4.Controls.Add(this.pictureBox11);
            this.tabPage4.Controls.Add(this.pictureBox12);
            this.tabPage4.Controls.Add(this.pictureBox13);
            this.tabPage4.Controls.Add(this.pictureBox14);
            this.tabPage4.Controls.Add(this.pictureBox5);
            this.tabPage4.Controls.Add(this.pictureBox6);
            this.tabPage4.Controls.Add(this.pictureBox7);
            this.tabPage4.Controls.Add(this.pictureBox8);
            this.tabPage4.Controls.Add(this.pictureBox9);
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.pictureBox2);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Controls.Add(this.storeCustom);
            this.tabPage4.Controls.Add(this.pictureBox0);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(266, 300);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Custom Characters";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // previewPic
            // 
            this.previewPic.BackColor = System.Drawing.Color.Black;
            this.previewPic.Location = new System.Drawing.Point(239, 261);
            this.previewPic.Name = "previewPic";
            this.previewPic.Size = new System.Drawing.Size(23, 35);
            this.previewPic.TabIndex = 95;
            this.previewPic.TabStop = false;
            this.previewPic.Paint += new System.Windows.Forms.PaintEventHandler(this.previewPic_Paint);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(188, 271);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 13);
            this.label13.TabIndex = 93;
            this.label13.Text = "Preview:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 92;
            this.label11.Text = "Screen:";
            // 
            // customCharScreenCmb
            // 
            this.customCharScreenCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.customCharScreenCmb.Enabled = false;
            this.customCharScreenCmb.FormattingEnabled = true;
            this.customCharScreenCmb.Location = new System.Drawing.Point(22, 82);
            this.customCharScreenCmb.Name = "customCharScreenCmb";
            this.customCharScreenCmb.Size = new System.Drawing.Size(75, 21);
            this.customCharScreenCmb.TabIndex = 91;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 78);
            this.label8.TabIndex = 90;
            this.label8.Text = "Custom characters \r\ncan be inserted in a \r\ntextbox by typing a \r\n\'\\\' followed by " +
                "the \r\nmemory location\r\n(ex. \"\\0\" or \"\\7\")";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 13);
            this.label5.TabIndex = 87;
            this.label5.Text = "Memory Location:";
            // 
            // memoryLocCmb
            // 
            this.memoryLocCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.memoryLocCmb.Enabled = false;
            this.memoryLocCmb.FormattingEnabled = true;
            this.memoryLocCmb.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.memoryLocCmb.Location = new System.Drawing.Point(22, 42);
            this.memoryLocCmb.Name = "memoryLocCmb";
            this.memoryLocCmb.Size = new System.Drawing.Size(75, 21);
            this.memoryLocCmb.TabIndex = 86;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(96, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 85;
            this.label7.Text = "Val2:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 84;
            this.label6.Text = "Val1:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(14, 276);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(79, 20);
            this.textBox10.TabIndex = 83;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(99, 276);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(79, 20);
            this.textBox9.TabIndex = 82;
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.White;
            this.pictureBox35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox35.Location = new System.Drawing.Point(235, 223);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(27, 27);
            this.pictureBox35.TabIndex = 81;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.White;
            this.pictureBox36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox36.Location = new System.Drawing.Point(207, 223);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(27, 27);
            this.pictureBox36.TabIndex = 80;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.Color.White;
            this.pictureBox37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox37.Location = new System.Drawing.Point(179, 223);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(27, 27);
            this.pictureBox37.TabIndex = 79;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.Color.White;
            this.pictureBox38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox38.Location = new System.Drawing.Point(151, 223);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(27, 27);
            this.pictureBox38.TabIndex = 78;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.White;
            this.pictureBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox39.Location = new System.Drawing.Point(123, 223);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(27, 27);
            this.pictureBox39.TabIndex = 77;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.Color.White;
            this.pictureBox30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox30.Location = new System.Drawing.Point(235, 195);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(27, 27);
            this.pictureBox30.TabIndex = 76;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.White;
            this.pictureBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox31.Location = new System.Drawing.Point(207, 195);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(27, 27);
            this.pictureBox31.TabIndex = 75;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.White;
            this.pictureBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox32.Location = new System.Drawing.Point(179, 195);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(27, 27);
            this.pictureBox32.TabIndex = 74;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.White;
            this.pictureBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox33.Location = new System.Drawing.Point(151, 195);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(27, 27);
            this.pictureBox33.TabIndex = 73;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.Color.White;
            this.pictureBox34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox34.Location = new System.Drawing.Point(123, 195);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(27, 27);
            this.pictureBox34.TabIndex = 72;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.White;
            this.pictureBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox25.Location = new System.Drawing.Point(235, 167);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(27, 27);
            this.pictureBox25.TabIndex = 71;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.White;
            this.pictureBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox26.Location = new System.Drawing.Point(207, 167);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(27, 27);
            this.pictureBox26.TabIndex = 70;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.White;
            this.pictureBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox27.Location = new System.Drawing.Point(179, 167);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(27, 27);
            this.pictureBox27.TabIndex = 69;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.Color.White;
            this.pictureBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox28.Location = new System.Drawing.Point(151, 167);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(27, 27);
            this.pictureBox28.TabIndex = 68;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.White;
            this.pictureBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox29.Location = new System.Drawing.Point(123, 167);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(27, 27);
            this.pictureBox29.TabIndex = 67;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.White;
            this.pictureBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox20.Location = new System.Drawing.Point(235, 139);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(27, 27);
            this.pictureBox20.TabIndex = 66;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.White;
            this.pictureBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox21.Location = new System.Drawing.Point(207, 139);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(27, 27);
            this.pictureBox21.TabIndex = 65;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.White;
            this.pictureBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox22.Location = new System.Drawing.Point(179, 139);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(27, 27);
            this.pictureBox22.TabIndex = 64;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.White;
            this.pictureBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox23.Location = new System.Drawing.Point(151, 139);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(27, 27);
            this.pictureBox23.TabIndex = 63;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.White;
            this.pictureBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox24.Location = new System.Drawing.Point(123, 139);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(27, 27);
            this.pictureBox24.TabIndex = 62;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.White;
            this.pictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox15.Location = new System.Drawing.Point(235, 111);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(27, 27);
            this.pictureBox15.TabIndex = 61;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.White;
            this.pictureBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox16.Location = new System.Drawing.Point(207, 111);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(27, 27);
            this.pictureBox16.TabIndex = 60;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.White;
            this.pictureBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox17.Location = new System.Drawing.Point(179, 111);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(27, 27);
            this.pictureBox17.TabIndex = 59;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.White;
            this.pictureBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox18.Location = new System.Drawing.Point(151, 111);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(27, 27);
            this.pictureBox18.TabIndex = 58;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.White;
            this.pictureBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox19.Location = new System.Drawing.Point(123, 111);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(27, 27);
            this.pictureBox19.TabIndex = 57;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.White;
            this.pictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox10.Location = new System.Drawing.Point(235, 83);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(27, 27);
            this.pictureBox10.TabIndex = 56;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.White;
            this.pictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox11.Location = new System.Drawing.Point(207, 83);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(27, 27);
            this.pictureBox11.TabIndex = 55;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.White;
            this.pictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox12.Location = new System.Drawing.Point(179, 83);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(27, 27);
            this.pictureBox12.TabIndex = 54;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.White;
            this.pictureBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox13.Location = new System.Drawing.Point(151, 83);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(27, 27);
            this.pictureBox13.TabIndex = 53;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.White;
            this.pictureBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox14.Location = new System.Drawing.Point(123, 83);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(27, 27);
            this.pictureBox14.TabIndex = 52;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(235, 55);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(27, 27);
            this.pictureBox5.TabIndex = 51;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.White;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(207, 55);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(27, 27);
            this.pictureBox6.TabIndex = 50;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.White;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(179, 55);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(27, 27);
            this.pictureBox7.TabIndex = 49;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.White;
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox8.Location = new System.Drawing.Point(151, 55);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(27, 27);
            this.pictureBox8.TabIndex = 48;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.White;
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox9.Location = new System.Drawing.Point(123, 55);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(27, 27);
            this.pictureBox9.TabIndex = 47;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(123, 27);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(27, 27);
            this.pictureBox4.TabIndex = 46;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(151, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(27, 27);
            this.pictureBox3.TabIndex = 45;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(179, 27);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(27, 27);
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(207, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(27, 27);
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // storeCustom
            // 
            this.storeCustom.Enabled = false;
            this.storeCustom.Location = new System.Drawing.Point(22, 113);
            this.storeCustom.Name = "storeCustom";
            this.storeCustom.Size = new System.Drawing.Size(75, 23);
            this.storeCustom.TabIndex = 41;
            this.storeCustom.Text = "Store";
            this.storeCustom.UseVisualStyleBackColor = true;
            this.storeCustom.Click += new System.EventHandler(this.enterCustom_Click);
            // 
            // pictureBox0
            // 
            this.pictureBox0.BackColor = System.Drawing.Color.White;
            this.pictureBox0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox0.Location = new System.Drawing.Point(235, 27);
            this.pictureBox0.Name = "pictureBox0";
            this.pictureBox0.Size = new System.Drawing.Size(27, 27);
            this.pictureBox0.TabIndex = 2;
            this.pictureBox0.TabStop = false;
            this.pictureBox0.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox35_MouseDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 544);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "TextLCD-full";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.brightnessTrkBr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contrastTrkBr)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.previewPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox attachedTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox versiontxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox serialTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.PictureBox pictureBox0;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button storeCustom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox memoryLocCmb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox row3;
        private System.Windows.Forms.TextBox row2;
        private System.Windows.Forms.TextBox row1;
        private System.Windows.Forms.TextBox row0;
        private System.Windows.Forms.ComboBox screenSizeCmb;
        private System.Windows.Forms.Button initButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label brightnessLbl;
        private System.Windows.Forms.CheckBox cursorBlinkChk;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox cursorChk;
        private System.Windows.Forms.CheckBox backlightChk;
        private System.Windows.Forms.ComboBox screenCmb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox customCharScreenCmb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox previewPic;
        private Dotnetrix.Controls.TrackBar contrastTrkBr;
        private Dotnetrix.Controls.TrackBar brightnessTrkBr;
    }
}

